/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2022/5/25 13:33:27                           */
/*==============================================================*/


drop table if exists Clazz;

drop table if exists Exam;

drop table if exists Notice;

drop table if exists Options;

drop table if exists Question;

drop table if exists Question_Option;

drop table if exists Stu_Answer;

drop table if exists Stu_Clazz;

drop table if exists Stu_Scores;

drop table if exists User;

drop table if exists stu_answer_option;

/*==============================================================*/
/* Table: Clazz                                                 */
/*==============================================================*/
create table Clazz
(
   id                   int not null,
   teacher_id           int,
   code                 varchar(30),
   name                 varchar(30),
   is_close             bool,
   primary key (id)
);

/*==============================================================*/
/* Table: Exam                                                  */
/*==============================================================*/
create table Exam
(
   id                   int not null,
   code                 varchar(255),
   clazz_id             int,
   start_time           timestamp,
   end_time             timestamp,
   primary key (id)
);

/*==============================================================*/
/* Table: Notice                                                */
/*==============================================================*/
create table Notice
(
   id                   int not null,
   clazz_id             int,
   primary key (id)
);

/*==============================================================*/
/* Table: Options                                               */
/*==============================================================*/
create table Options
(
   id                   int not null,
   text                 varchar(255),
   primary key (id)
);

/*==============================================================*/
/* Table: Question                                              */
/*==============================================================*/
create table Question
(
   id                   int not null,
   text                 varchar(255),
   img                  varchar(255),
   category             varchar(20),
   sample_answer        varchar(255),
   clazz_code           varchar(30),
   ac_scores            int,
   tot_scores           int,
   difficulty_ratio     decimal,
   primary key (id)
);

/*==============================================================*/
/* Table: Question_Option                                       */
/*==============================================================*/
create table Question_Option
(
   id                   int not null,
   question_id          int,
   option_id            int,
   is_correct           bool,
   primary key (id)
);

/*==============================================================*/
/* Table: Stu_Answer                                            */
/*==============================================================*/
create table Stu_Answer
(
   id                   int not null,
   exam_id              int,
   question_id          int,
   question_text        varchar(255),
   question_img         varchar(255),
   question_category    varchar(20),
   stu_id               int,
   answer_content       varchar(255),
   correct_answer       varchar(255),
   primary key (id)
);

/*==============================================================*/
/* Table: Stu_Clazz                                             */
/*==============================================================*/
create table Stu_Clazz
(
   id                   int not null,
   stu_id               int,
   clazz_id             int,
   primary key (id)
);

/*==============================================================*/
/* Table: Stu_Scores                                            */
/*==============================================================*/
create table Stu_Scores
(
   id                   int not null,
   clazz_id             int,
   exam_id              int,
   stu_id               int,
   scores               decimal,
   end_time             timestamp,
   state                varchar(20),
   primary key (id)
);

/*==============================================================*/
/* Table: User                                                  */
/*==============================================================*/
create table User
(
   id                   int not null,
   code                 varchar(20),
   name                 varchar(20),
   pwd                  varchar(20),
   sex                  varchar(10),
   user_type            varchar(10),
   fullname             varchar(20),
   primary key (id)
);

/*==============================================================*/
/* Table: stu_answer_option                                     */
/*==============================================================*/
create table stu_answer_option
(
   id                   int not null,
   stu_answer_id        int,
   option_text          varchar(255),
   primary key (id)
);

